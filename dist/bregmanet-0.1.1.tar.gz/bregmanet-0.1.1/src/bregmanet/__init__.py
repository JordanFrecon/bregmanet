from bregmanet.mlp import MLP
from bregmanet.resnet_small import bresnet20, bresnet32, bresnet44, bresnet56, bresnet110, bresnet1202
from bregmanet.resnet_large import bresnet18, bresnet34, bresnet50, bresnet101, bresnet152, bresnext50_32x4d,\
    bresnext101_32x8d, wide_bresnet50_2, wide_bresnet101_2
